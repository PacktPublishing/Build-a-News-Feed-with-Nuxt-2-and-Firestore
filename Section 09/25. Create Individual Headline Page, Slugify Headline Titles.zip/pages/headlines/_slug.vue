<template>
  <p>{{$route.params.slug}}</p>
</template>
