<template>
  <div>
    <p>Nuxt News</p>
    <md-button>Submit</md-button>
  </div>
</template>
