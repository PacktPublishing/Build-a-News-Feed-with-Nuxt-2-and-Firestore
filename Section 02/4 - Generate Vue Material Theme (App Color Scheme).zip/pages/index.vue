<template>
  <div>
    <p>Nuxt News</p>
    <md-button class="md-primary">Submit</md-button>
  </div>
</template>
