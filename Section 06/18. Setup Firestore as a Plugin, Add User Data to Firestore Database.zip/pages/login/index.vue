<template>
  <p>login</p>
</template>

<script>
export default {
  middleware: "auth"
};
</script>